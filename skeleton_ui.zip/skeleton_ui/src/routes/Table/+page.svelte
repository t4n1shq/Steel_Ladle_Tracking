<script>
    // @ts-nocheck
    import Navbar from "../Navbar.svelte";
    import Table from "./Table.svelte";
        
    </script>
    
    
    <Navbar />
    This is the table page
    <Table />
    