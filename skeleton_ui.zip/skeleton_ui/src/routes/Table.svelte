<script>
    
</script>

<div class="table-container">
	<!-- Native Table Element -->
	<table class="table table-hover table-compact">
		<thead>
			<tr>
				<th class = "table-sort-asc">
					
				</th>
				<th class = "table-sort-asc">Ladle ID</th>
				<th class = "table-sort-asc">Status</th>
				<th class = "table-sort-asc">Entry Time</th>
				<th class = "table-sort-asc">Exit Time</th>
				<th class = "table-sort-asc">Heat Cycles</th>
			</tr>
		</thead>
		<tbody>
			<Row />
		</tbody>
	</table>
</div>
