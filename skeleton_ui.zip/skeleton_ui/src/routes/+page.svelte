<script>
	import Navbar from './Navbar.svelte';
</script>

<!-- <Login /> -->

<Navbar />

<!-- <Table /> -->